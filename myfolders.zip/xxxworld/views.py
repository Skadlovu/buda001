from django.core.mail import send_mail
from django.conf import settings
from contact.models import Contact
from contact.forms import ContactForm
from django.shortcuts import render


def assist(request):
    if request.method == 'POST':
        con_form = ContactForm(request.POST)
        if con_form.is_valid():
            # Save the form data to the Contact model
            contact = form.save(commit=False)
            contact.save()

            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            sender_email = form.cleaned_data['email']

            # Send an email
            send_mail(
                'Subject here',
                'Here is the message.',
                settings.EMAIL_HOST_USER,
                ['admin@xxxworld.site'],
                fail_silently=False,
            )

            return render(request, 'success.html')
    else:
        con_form = ContactForm()
    context = {'con_form': con_form}
    return render(request, 'assist.html', context)

def success(request):
    return render(request,'success.html')
