from storages.backends.gcloud import GoogleCloudStorage


# Use the custom storage class for static and media
Static = lambda: GoogleCloudStorage(location='static')
Media = lambda: GoogleCloudStorage(location='media')

