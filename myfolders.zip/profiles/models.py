from django.db import models
from django.contrib.auth.models import User
from PIL import Image
from io import BytesIO
import requests


class Profile(models.Model):
	user=models.OneToOneField(User, on_delete=models.CASCADE)
	image=models.ImageField(default='mountain.jpeg', upload_to='profile-pics', blank=True, null=True, verbose_name='Profile picture')
	user_bio=models.TextField(max_length=300,blank=True, null=True)


	def __str__(self):
		return f'{self.user.username}Profile'

	def save(self, *args, **kwargs):
	    super().save(*args, **kwargs)

	    if self.image:
	        response = requests.get(self.image.url)
	        if response.status_code == 200:
	            img = Image.open(BytesIO(response.content))
	            if img.height > 150 or img.width > 150:
	                output_size = (150, 150)
	                img.thumbnail(output_size)
	                in_mem_file = BytesIO()
	                img.save(in_mem_file, format='JPEG')
	                in_mem_file.seek(0)
	                self.image.save(self.image.name, in_mem_file, save=False)
